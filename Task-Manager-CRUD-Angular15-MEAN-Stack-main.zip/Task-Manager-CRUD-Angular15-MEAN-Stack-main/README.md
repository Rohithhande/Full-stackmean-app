# Task-Manager-CRUD-Angular15-MEAN-Stack


A basic Task Manager Web Application developed on MEAN Stack with Angular version 15.

<a href="https://ibb.co/NtvX49L"><img src="https://i.ibb.co/343wJp0/Homepage2.png" alt="Homepage2" border="0"></a>


<a href="https://ibb.co/3vdnfPY"><img src="https://i.ibb.co/8bsHzQ4/Edit.png" alt="Edit" border="0"></a>
