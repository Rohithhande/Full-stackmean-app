export class Task{
    _id:string='';
    task_name:string='';
    complete:boolean=false;

    
}